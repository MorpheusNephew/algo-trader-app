"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.handler = void 0;

var _clients = _interopRequireDefault(require("@morpheusnephew/td-ameritrade/dist/clients"));

var _config = require("/opt/nodejs/config");

var _connectionUtils = require("/opt/nodejs/connectionUtils");

var _dateFns = require("date-fns");

var _connectiondb = require("/opt/nodejs/connectiondb");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

const connectionType = 'td';

const handler = /*#__PURE__*/function () {
  var _ref = _asyncToGenerator(function* (_event) {
    const connections = yield (0, _connectiondb.getConnections)({
      connectionType
    });

    const mapper = /*#__PURE__*/function () {
      var _ref2 = _asyncToGenerator(function* (connection) {
        const currentDate = new Date();
        const tokenExpirationDate = (0, _dateFns.parseISO)(connection.refreshTokenExpiration);
        const daysDiff = (0, _dateFns.differenceInCalendarDays)(tokenExpirationDate, currentDate);

        if (daysDiff < 2) {
          const {
            tdConsumerKey
          } = yield _config.Config.getConfig();
          const {
            connectionId,
            refreshToken,
            username
          } = connection;
          const client = new _clients.default({
            refreshToken: refreshToken,
            clientId: tdConsumerKey
          });
          console.log(`Updating refresh token for: ${username}`);
          const {
            data: tokenResponse
          } = yield client.auth.refreshRefreshToken();
          const connectionToUpdate = yield (0, _connectionUtils.convertTokenToIConnection)(tokenResponse, connectionType, connectionId);
          yield (0, _connectiondb.updateConnectionTokens)(username, connectionId, connectionToUpdate);
          console.log(`Refresh token for ${username} has been updated`);
        }

        return true;
      });

      return function mapper(_x2) {
        return _ref2.apply(this, arguments);
      };
    }();

    yield Promise.all(connections.map(mapper));
    const response = {
      statusCode: 200
    };
    return response;
  });

  return function handler(_x) {
    return _ref.apply(this, arguments);
  };
}();

exports.handler = handler;